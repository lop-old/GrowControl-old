libAuthKit.jnilib 
and the following java packages
glguerin.*
app.authkit.*
app.hex.*
app.util.*
are part of Greg Guerin's AuthKit

see http://www.amug.org/~glguerin/sw/#authkit    
it released under "Artistic" license



