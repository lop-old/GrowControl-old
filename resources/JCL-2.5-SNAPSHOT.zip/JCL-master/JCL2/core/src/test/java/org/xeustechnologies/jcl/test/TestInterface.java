package org.xeustechnologies.jcl.test;

public interface TestInterface {
    public String sayHello();
}
